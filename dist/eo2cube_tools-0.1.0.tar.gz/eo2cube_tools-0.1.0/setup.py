# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['eo2cube_tools']

package_data = \
{'': ['*']}

install_requires = \
['bokeh>=2.2.3,<3.0.0',
 'dask>=2021.1.1,<2022.0.0',
 'datashader>=0.12.0,<0.13.0',
 'folium>=0.12.1,<0.13.0',
 'geopandas>=0.8.2,<0.9.0',
 'holoviews>=1.14.1,<2.0.0',
 'pandas>=1.2.1,<2.0.0',
 'panel>=0.10.3,<0.11.0',
 'rasterio>=1.2.0,<2.0.0',
 'xarray>=0.16.2,<0.17.0']

setup_kwargs = {
    'name': 'eo2cube-tools',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Steve',
    'author_email': 'steven.hill@uni-wuerzburg.de',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)

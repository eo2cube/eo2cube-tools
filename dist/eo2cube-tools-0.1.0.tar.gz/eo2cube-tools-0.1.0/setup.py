# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['eo2cube_tools']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'eo2cube-tools',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Steve',
    'author_email': 'steven.hill@uni-wuerzburg.de',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
